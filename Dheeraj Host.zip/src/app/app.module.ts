import { NgModule } from '@angular/core';
import { APP_PROVIDERS } from './app.providers';
import { AppComponent } from './app.component';
import { FormsModule } from '@angular/forms';
import { appRoutingProviders, routing } from './app.routing';
import { NavbarModule } from './shared';
import { HomeModule } from './home/home.module';
import { BrowserModule } from '@angular/platform-browser';
// import {CalendarModule} from 'primeng/primeng';

@NgModule({
    declarations: [
        AppComponent
    ],
    imports: [
        NavbarModule,
        HomeModule,
        FormsModule,
        BrowserModule,
        routing
    ],
    providers: [
        APP_PROVIDERS,
        appRoutingProviders
    ],
    bootstrap: [AppComponent]
})
export class AppModule {
}
