declare var System: any;
declare var URLPolyfill: any;
(function (global) {

    let nativeURL: any;
    try {
        nativeURL = new global.URL('test:///').protocol === 'test:';
    } catch (e) {
        nativeURL = null;
    }

    let URL = nativeURL ? global.URL : URLPolyfill;

    System.register = function (name, deps, declare) {
        if (typeof name !== 'string') {
            declare = deps; deps = name; name = null;
        }

        if (typeof declare === 'boolean') {
            return this.registerDynamic.apply(this, arguments);
        }

        this.pushRegister_({
            amd: false,
            entry: {
                name: name,
                deps: deps,
                declare: declare,
                declarative: true,
                executingRequire: false,
                esmExports: false,
                evaluated: false,
                originalIndices: null,
                execute: null,
                normalizedDeps: null,
                groupIndex: null,
                module: null,
                esModule: null
            }
        });
    };
    System.registerDynamic = function (name, deps, declare, execute) {

        if (typeof name !== 'string') {
            execute = declare;
            declare = deps;
            deps = name;
            name = null;
        }

        this.pushRegister_({
            amd: false,
            entry: {
                name: name,
                deps: deps,
                originalIndices: null,
                declare: null,
                execute: execute,
                executingRequire: declare,
                declarative: false,
                normalizedDeps: null,
                groupIndex: null,
                evaluated: false,
                module: null,
                esModule: null,
                esmExports: false
            }
        });
    };
    System.reduceRegister__ = System.reduceRegister_;
    System.reduceRegister_ = function (load, register) {
        let entry = register && register.entry;
        if (entry && entry.name) {
            entry.name = (load && load.metadata && load.metadata.decanonicalize === false) ?
                new URL(entry.name, load.address).href.replace(/%05/g, '#') :
                (this.decanonicalize || this.normalize).call(this, entry.name);
        }
        System.reduceRegister__.call(this, load, register);
    };

})(self);
