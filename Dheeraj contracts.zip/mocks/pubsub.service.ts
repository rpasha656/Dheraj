import { Injectable } from '@angular/core';
import { Subject, Observable} from 'rxjs/Rx';
import { PubSubServiceContract } from '../src/pubsub-service.contract';
import { Http, Response, Headers, RequestOptions} from '@angular/http';
import {FileMetadata} from './filemetadata.model';

@Injectable()
export class PubSubService extends PubSubServiceContract {
    private subjects: { [index: string]: Subject<any> };
    private docpubUrl = 'filemetadata.json';  // URL to web api
    public http: Http;

    constructor() {
        super();
        this.subjects = {};
    }
    publish(subject: string, value: any) {
        let rxSubject = this.subjects[subject];
        if (!rxSubject) {
            rxSubject = this.subjects[subject] = new Subject<any>();
        }
        rxSubject.next(value);
    }
    subscribe(subject: string, handler: (value: any) => void, error?: (error: any) => void, complete?: () => void) {
        let rxSubject = this.subjects[subject];
        if (!rxSubject) {
            rxSubject = this.subjects[subject] = new Subject<any>();
        }
        return rxSubject.subscribe(handler, error, complete);
    }
    addFileMetaDate(body: Object): Promise<boolean> {
        let bodyString = JSON.stringify(body); // Stringify payload
        let headers = new Headers({ 'Content-Type': 'application/json' }); // ... Set content type to JSON
        let options = new RequestOptions({ headers: headers }); // Create a request option

        return new Promise<boolean> ((resolve,reject) =>
        this.http.post(this.docpubUrl, body, options) // ...using post request
            .subscribe((res) =>{
                    res.json();
                    resolve(true);
                }, // ...and calling .json() on the response to return data
            (error) =>{ /*Observable.throw(error.json().error || 'Server error')*/
                    console.log(error.json().error);
                    reject(false);
    })
    )
    }
}
